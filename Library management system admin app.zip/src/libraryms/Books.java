/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libraryms;

/**
 *
 * @author TOSHIBA
 */
public class Books {
    private int accnum;
    private String datereceived;
    private String classificationnum;
    private String author;
    private String title;
    private String edition;
    private String volume;
    private String numofpages;
    private String sourceoffunds;
    private String costprice;
    private String placepublication;
    private String publisher;
    private String copyrightyear;
    private String remarks;    
    
    
    public Books(int accnum1 , String datereceived1, String classificationnum1, String author1, String title1, String edition1, String volume1, String numofpages1, String sourceoffunds1,String costprice1, String placepublication1,String publisher1,String copyrightyear1,String remarks1)
    {
        this.accnum = accnum1;
        this.datereceived = datereceived1;
        this.classificationnum = classificationnum1;
        this.author=author1;
        this.title=title1;
        this.edition=edition1;
        this.volume=volume1;
        this.numofpages=numofpages1;
        this.sourceoffunds=sourceoffunds1;
        this.costprice=costprice1;
        this.placepublication=placepublication1;
        this.publisher=publisher1;
        this.copyrightyear=copyrightyear1;
        this.remarks=remarks1;
        
     
    }
    
    public int getaccNum()
    {
        return accnum;
    }
    
    public String getDateReceived()
    {
        return datereceived;
    }
    
    public String getClassificationNum()
    {
        return classificationnum;
    }
    public String getAuthor()
    {
        return author;
    }
    
    public String getTitle()
    {
        return title;
    }
    
     public String getEdition()
    {
        return edition;
    }
    
    public String getVolume()
    {
        return volume;
    }
    public String getNumOfPages()
    {
        return numofpages;
    }
    
    public String getSourceOfFunds()
    {
        return sourceoffunds;
    }
    
    public String getCostPrice()
    {
        return costprice;
    }
    
    public String getPlacePublication()
    {
        return placepublication;
    }
    
    
    public String getPublisher()
    {
        return publisher;
    }
    
    public String getCopyrightYear()
    {
        return copyrightyear;
    }
    public String getRemarks()
    {
        return remarks;
    }
}
